package com.jdbcdao;

import java.util.*;

import com.Databaseconnect.DataConnect;
import com.training.project.pojo.Product;

import java.sql.*;
public class StoreInformationDao {
List<Product> plist;
Connection con;
PreparedStatement stm;
Scanner sc;
public StoreInformationDao(){
	con=DataConnect.getConnect();
	plist=new ArrayList<Product>();
	sc=new Scanner(System.in);
}
public void insert() throws SQLException {
	System.out.println("enter howmany produt do you want to store");
	int n=sc.nextInt();
	for(int i=0;i<n;i++) {
		Product p=new Product();
		System.out.println("enter productid");
		p.setProductId(sc.nextInt());
		System.out.println("enter productname");
		p.setProductName(sc.next());
		//System.out.println("enter selling price");
		//p.setSellingprice(sc.nextInt());
		System.out.println("enter itemname");
		p.setItemname(sc.next());
		System.out.println("enter ctaegory");
		p.setCategory(sc.next());
		System.out.println("enter buying price");
		int price=sc.nextInt();
		p.setBuyingprice(price);
		p.setSellingprice(price);
		plist.add(p);
	}
	insertDeatils(plist);
}
private void insertDeatils(List<Product> plist2) throws SQLException {
	// TODO Auto-generated method stub
	stm=con.prepareStatement("insert into product values(?,?,?,?,?,?)");
	for(Product p:plist2) {
		stm.setInt(1, p.getProductId());
		stm.setString(2, p.getProductName());
		stm.setInt(3, p.getSellingprice());
		stm.setString(4, p.getItemname());
		stm.setString(5, p.getCategory());
		stm.setInt(6, p.getBuyingprice());
		int res=stm.executeUpdate();
		if(res>0){
			System.out.println("inserted");
		}
	}
}
public void searchbyid() throws SQLException, ProductIdException {
	System.out.println("enter product id");
	int pid=sc.nextInt();
	stm=con.prepareStatement("select * from product where productid=?");
	stm.setInt(1, pid);
	ResultSet res=stm.executeQuery();
	if(res.next()) {
		System.out.println("product name"+res.getInt(1));
		System.out.println("product name"+res.getString(2));
		System.out.println("product selling price"+res.getInt(3));
		System.out.println("product name"+res.getString(4));
		
	}else {
		throw new ProductIdException();
	}
}
public void listbycategory() throws SQLException {
	System.out.println("enter product catgory");
	String cat=sc.next();
	stm=con.prepareStatement("select * from product where category=?");
	stm.setString(1, cat);
	ResultSet res=stm.executeQuery();
	while(res.next()) {
		System.out.println("product name"+res.getInt(1));
		System.out.println("product name"+res.getString(2));
		System.out.println("product selling price"+res.getInt(3));
		System.out.println("product category"+res.getString(4));	
	}
}
public void byname() throws SQLException {
	System.out.println("enter product name");
	String pname=sc.next();
	stm=con.prepareStatement("select * from product where productname=?");
	stm.setString(1, pname);
	ResultSet res=stm.executeQuery();
	while(res.next()) {
		System.out.println("product id"+res.getInt(1));
		System.out.println("product name"+res.getString(2));
		System.out.println("product selling price"+res.getInt(3));
		System.out.println("product category"+res.getString(4));	
	}
	
}
public void caltotal() throws SQLException {
	int total=0;
	stm=con.prepareStatement("select byuingprice from product");
	ResultSet res=stm.executeQuery();
	while(res.next()) {
		total=total+res.getInt(1);
	}
System.out.println("total money spend"+total);
}
public void calProfit() throws SQLException {
	int profit=0;
	System.out.println("enter product catgory");
	String cat=sc.next();
	stm=con.prepareStatement("select category,sellingprice,byuingprice from product where category=?");
	stm.setString(1, cat);
	ResultSet res=stm.executeQuery();
	while(res.next()) {
		profit=profit+res.getInt(2)-res.getInt(3);
	}
	System.out.println("profit is"+profit);
}
}
