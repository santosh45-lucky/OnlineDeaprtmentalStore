package com.jdbcdao;

public class UserNotFoundException extends Exception{
	public String getMessage(){
		return "User Doesn't Exits";	
		}
}
