package com.jdbcdao;

public class ProductIdException extends Exception{
public String getMessage() {
	return "invalid productid "
			+ "Please enter corect product id";
}
}
