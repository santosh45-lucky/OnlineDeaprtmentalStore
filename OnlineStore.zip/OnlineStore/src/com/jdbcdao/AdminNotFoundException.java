package com.jdbcdao;

public class AdminNotFoundException extends Exception{
public String getMessage() {
	return "Invalid Username or passsword";
}
}
