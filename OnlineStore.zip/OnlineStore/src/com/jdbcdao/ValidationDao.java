package com.jdbcdao;
import java.util.*;

import com.Databaseconnect.DataConnect;
import com.training.project.menu.Menu1;
import com.training.project.pojo.Product;
import com.training.project.service.ProductService;

import java.sql.*;
public class ValidationDao {
private Scanner sc;
 Connection con;
ProductService pservice;
PreparedStatement stm;
List<Product> plist;
	public ValidationDao(){
		con=DataConnect.getConnect();
		sc=new Scanner(System.in);
		pservice=new ProductService();
		plist=new ArrayList<>();
	
	}
	public void register() throws SQLException {
		System.out.println("enter howmany user u want to insert");
		int n=sc.nextInt();
		stm=con.prepareStatement("insert into user values(?,?,?,?)");
		for(int i=0;i<n;i++) {
			System.out.println("enter user name");
			stm.setString(1, sc.next());
			System.out.println("enter email");
			stm.setString(2, sc.next());
			System.out.println("enter password");
			stm.setString(3, sc.next());
			stm.setInt(4,100);
			int res=stm.executeUpdate();
			if(res>0) {
				System.out.println("data inserted");
				System.out.println("you get 100 supeercoins");
			}
		}
	}
	public void checkUser() throws SQLException,UserNotFoundException {
	System.out.println("enter username");
	String uname=sc.next();
	System.out.println("enter password");
	String pass=sc.next();
		stm=con.prepareStatement("select * from user where name=? && password=?");
		stm.setString(1, uname);
		stm.setString(2, pass);
		ResultSet res=stm.executeQuery();
		if(res.next()) {
			System.out.println("valid user");
			userAuthentication();
		}else {
			//System.out.println("invalid user");
			throw new UserNotFoundException();
		}
	}
	public void checkAdmin() throws SQLException, AdminNotFoundException {
		System.out.println("enter adminname");
		String aname=sc.next();
		System.out.println("enter password");
		String pass=sc.next();
			stm=con.prepareStatement("select * from admin where name=? && password=?");
			stm.setString(1, aname);
			stm.setString(2, pass);
			ResultSet res=stm.executeQuery();
			if(res.next()) {
				System.out.println("Login Sucessfullly....");
				adminAuthentication();
			}else {
				//System.out.println("!!!!Invalid username or password!!!!");
				throw new AdminNotFoundException();
			}	
	}
	public void adminAuthentication() throws SQLException {
		int ch=0;
		String choice="y";
		while(choice.equals("y")){
			System.out.println("Enter your choice...");
			System.out.println("1.Insert into Store");
			System.out.println("2.Serach product ById");
			System.out.println("3.Display by category");
			System.out.println("4.Calculate total amount");
			System.out.println("5.Search Product ByName");
			System.out.println("6.Calculate profit amount");
			System.out.println("7.exit");
			
			ch=sc.nextInt();
			switch(ch) {
			case 1:
				System.out.println("insert the item");
				pservice.itemInsert();
				break;
			case 2:
				try {
					pservice.viewProduct();
				} catch (ProductIdException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
				break;
			case 3:
				pservice.byCategory();
				break;
			case 4:
				pservice.total();
				break;
				case 5:
				pservice.byName();
					break;
				case 6:
					pservice.findProfit();		
					break;
				case 7:
		//	System.exit(0);
					Menu1 m=new Menu1();
			m.showDeatils();
			
			}
			System.out.println("Do you want to continue Y/N");
			choice=sc.next();
		}
	}
	public void userAuthentication() throws SQLException {
	int ch=0;
	String choice="y";
	while(choice.equals("y")){
		System.out.println("Enter your choice....");
		System.out.println("1.Login and view product");
		System.out.println("2.Register");
		System.out.println("3.Provide supercoins");
		System.out.println("4.Filter by category and price");
		System.out.println("5.Buy product by name or id");
		System.out.println("6.Add product to Cart");
		System.out.println("7.Generate Final Bill");
		System.out.println("8.exit");
		ch=sc.nextInt();
		switch(ch) {
		case 1:
		//	checkUser();
			ViewProduct();
			break;
		case 2:
			register();
			break;
		case 3:
			System.out.println("you get 100 spercoins");
			break;
		case 4:
			filterBy();
			break;
		case 5:
			buyproduct();
			break;
		case 6:
			addProduct();
			break;
		case 7:
			genetrateBill();
			break;
		case 8:
			System.exit(0);
			break;
			}
		System.out.println("do you want to contiinue y/n");
		choice=sc.next();
	}

	}
	public void ViewProduct() throws SQLException {
	stm=con.prepareStatement("select productname from product");
	ResultSet res=stm.executeQuery();
	System.out.println("Avaiable product....");
	while(res.next()) {
		System.out.println(res.getString(1));
	}
	}
	public void filterBy() throws SQLException {
		System.out.println("please select by whihch you wwant to filter cataegory or price");
		String f=sc.next();
		if(f.equals("catagory")){ {
		System.out.println("enter product catgory");
		String cat=sc.next();
		stm=con.prepareStatement("select * from product where category=?");
		stm.setString(1, cat);
		ResultSet res=stm.executeQuery();
		while(res.next()) {
			System.out.println("product id"+res.getInt(1));
			System.out.println("product name"+res.getString(2));
			System.out.println("product selling price"+res.getInt(3));
			//System.out.println("product category"+res.getString(4));	
		}
	}
		
	}else {
		System.out.print("filter by  price");
		stm=con.prepareStatement("select * from product order by sellingprice" );
		ResultSet res=stm.executeQuery();
		while(res.next()) {
		//	System.out.println("product id"+res.getInt(1));
			System.out.println("product name"+res.getString(2));
			System.out.println("product selling price"+res.getInt(3));
			System.out.println("product category"+res.getString(4));	
		}
}
	}
	public void buyproduct() throws SQLException {
		System.out.println("enter product name or id which you want to purchase");
		int id=sc.nextInt();
		//System.out.println("enter product name");
		//String pname=sc.next();
		stm=con.prepareStatement("select * from product where productid=?");
		stm.setInt(1, id);
		ResultSet res=stm.executeQuery();
		while(res.next()) {
			System.out.println("product id"+res.getInt(1));
			System.out.println("product name"+res.getString(2));
			System.out.println("product selling price"+res.getInt(3));
			System.out.println("product category"+res.getString(4));
			
		}
	}
	public void addProduct() {
		
		System.out.println("enter how many product you want to add");
		int n=sc.nextInt();
		for(int i=0;i<n;i++){
			Product p=new Product();
			System.out.println("enter product name");
			p.setProductName(sc.next());
			plist.add(p);
		}
		System.out.println("**PRODUCT added to cart**");
		for(Product p:plist) {
			System.out.println("product name is"+p.getProductName());
		}
	}
	
	public void genetrateBill() throws SQLException {
		billGenerate(plist);
	}
	private void billGenerate(List<Product> plist2) throws SQLException {
		// TODO Auto-generated method stub
		int total=0;
		stm=con.prepareStatement("select *from product where productname=?");
	for(Product p:plist2) {
		//total=total+p.getSellingprice();
		stm.setString(1, p.getProductName());
		//stm.setInt(2, p.getSellingprice());
		ResultSet res=stm.executeQuery();
		while(res.next()) {
			total=total+res.getInt(3);
			System.out.println("Your product which you purchase:");
			System.out.println(res.getString(2));
		}
		}
		System.out.println("total money yppou sspend is"+total);
		System.out.println("**THANK YOU FOR SHOPPING");
	}

}