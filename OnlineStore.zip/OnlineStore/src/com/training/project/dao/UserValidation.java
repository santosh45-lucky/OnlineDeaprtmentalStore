package com.training.project.dao;
import java.sql.SQLException;
import java.util.*;

import com.training.project.pojo.User;
import com.training.project.service.ProductService;
import com.training.project.service.UserService;
public class UserValidation {

	String adminname="santosh";
	String adminpassword="password";
	Scanner sc;
	ProductService pservice;
	UserService uservice;
	List<User> ulist;

	
	public UserValidation(){
		sc=new Scanner(System.in);
		ulist=new ArrayList<>();
	pservice=new ProductService();
		//uservice=new UserService();
		
	}
	public void checkadmin() throws SQLException {
		System.out.println("enter username");
		String name=sc.next();
		System.out.println("enter password");
		String pass=sc.next() ;
		if(name.equals(adminname)&&(pass.equals(adminpassword))) {
			adminAuthentication();
					}else {
			System.out.println("invalid user");
		}
		}
	
	public void userRegister() {
		System.out.println("enter howmany user you waant to insert");
		int n=sc.nextInt();
		for(int i=0;i<n;i++) {
			User u=new User();
			System.out.println("enter user name");
			u.setUserName(sc.next());
			System.out.println("enter password");
			u.setPassword(sc.next());
			System.out.println("enter emailid");
			u.setEmail(sc.next());
			ulist.add(u);
		
		}
			
		}
	public void usercheck() throws SQLException {
		System.out.println("user name");
		String uname=sc.next();
		System.out.println("enter passsword");
		String upass=sc.next();
		for(User u:ulist) {
			if(uname.equals(u.getUserName())&&(upass.equals(u.getPassword()))) {
				int ch=0;
				String choice="y";
				while(choice.equals("y")){
					System.out.println("enter your choice");
					System.out.println("1.login and view product");
					System.out.println("2.register");
					System.out.println("3.provide supercoins");
					System.out.println("4.display by category");
					
					System.out.println("5.exit");
					ch=sc.nextInt();
					switch(ch) {
					case 1:
						usercheck();

						break;
						
					case 2:
					userRegister();
						

						break;
					case 3:
						userRegister();
						System.out.println("you get 100 spercoins");
						break;
					case 4:
					//	pservice.viewProduct();
					}
					System.out.println("do you want to contiinue");
					choice=sc.next();
				}

				
						}else {
				System.out.println("invalid");
			}
		}
	}
	
	public void userauthentication() {
			}

	
	public void adminAuthentication() throws SQLException {
		int ch=0;
		String choice="y";
		while(choice.equals("y")){
			System.out.println("enter your choice");
			System.out.println("1.insert");
			System.out.println("2.display by category");
			System.out.println("3.display by price");
			System.out.println("4to check total amount");
			System.out.println("5.diplay profit amount");
			System.out.println("6.");
			System.out.println("7.sellingprice");
			System.out.println("8.exit");
			ch=sc.nextInt();
			switch(ch) {
			case 1:
				System.out.println("insert the item");
				//pservice.iteminsert();

				break;
				
			case 2:
		//		pservice.viewProduct();

				break;
			case 3:
			//	pservice.byname();
				break;
			case 4:
				pservice.total();
				break;
				case 5:
				//	pservice.findprofit();			
					break;
				case 6:
					pservice.total();
					break;
				case 7:
					//pservice.sellingprice();
		
			}
			System.out.println("do you want to contiinue");
			choice=sc.next();
		}
		

	}
	
}
