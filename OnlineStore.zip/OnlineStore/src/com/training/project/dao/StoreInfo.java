package com.training.project.dao;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Stream;
import java.util.*;
import com.training.project.pojo.*;
public class StoreInfo 
{
Map<Integer,Product> pmap;
Product pobj;
Scanner sc;
double sum=0;
double profit=0;
double sellingprice=0;
public StoreInfo() {
	sc=new Scanner(System.in);
	pmap=new HashMap<Integer,Product>();
	pobj=new Product();
	
}
public void insertitem()

{
	System.out.println("enter howmany item you want to item");
	int n=sc.nextInt();
	for(int i=0;i<n;i++) {
		Product m=new Product();
		System.out.println("enter item name");
		m.setProductName(sc.next());
        m.setItemname(m.getProductName());
		System.out.println("enter item category");
		m.setCategory(sc.next());
		System.out.println("enter item id");
		int code=m.setProductId(sc.nextInt());

		System.out.println("enter item price");
		m.setBuyingprice(sc.nextInt());
		pmap.put(code, m);
	}
	pobj.setMap(pmap);
}
public void calsellingprice() {
	pmap.entrySet().stream().forEach(s->{
		sellingprice=s.getValue().getBuyingprice()*0.5+s.getValue().getBuyingprice();
		System.out.println(sellingprice);
	});
}
public void search() {
	System.out.println("enter product id");
	int pid=sc.nextInt();
	Stream<Entry<Integer, Product>>filterset = pmap.entrySet().stream().filter(pin-> pin.getValue().getProductId()==pid);
	filterset.forEach(nn->
		{
			System.out.println(nn.getValue().getItemname());
		});
	
	}
public void profit() {
	System.out.println("enter category which you want to display");
	String cat=sc.next();


	boolean ans=pmap.entrySet().stream().allMatch(n->n.getValue().getCategory().equals(cat));
	if(ans) {
        pmap.values().stream().forEach(n->
        {
        	 profit=(n.getBuyingprice()*0.5)+n.getBuyingprice();
       }
        	
        );
System.out.println("profit is"+profit);
	}else {
		System.out.println("invalid");
	}
	
	
}
public void viewproduct() {
	System.out.println("enter category which you want to display");
	String cat=sc.next();


	boolean ans=pmap.entrySet().stream().allMatch(n->n.getValue().getCategory().equals(cat));
	if(ans) {
		pmap.values().stream().forEach(nn->
		{
			System.out.println(nn.getProductName());
			System.out.println(nn.getProductId());
		});
	}else {
		System.out.println("entter valid id");
	}

}
public void serachPrice() {
	System.out.println("enter price");
	double price=sc.nextDouble();
	//double price
	boolean result=pmap.entrySet().stream().anyMatch(product->product.getValue().getBuyingprice()==price);
	if(result) {
		pmap.values().stream().forEach(nn->
		{
			System.out.println(nn.getItemname());
		});

		
	}else{
		
	System.out.println("enter coreect price");
	}
}
//public void () {
	
//}
public void totalamount() {

	System.out.println("enter category which you want to display");
	String cat=sc.next();

	//boolean ans=list.stream().allMatch(n->n.getName().equals(un)&&(n.getPass().equals(ps)));
	boolean ans=pmap.entrySet().stream().allMatch(n->n.getValue().getCategory().equals(cat));
	if(ans) {
        pmap.values().stream().forEach(t->
        {
        	 sum=sum+t.getBuyingprice();
       }
        	
        );
        System.out.println("totalamount is"+sum);

	}
}
}
