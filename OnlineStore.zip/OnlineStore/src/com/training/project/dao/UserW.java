package com.training.project.dao;

import com.training.project.pojo.User;
import com.training.project.service.ProductService;
import com.training.project.service.UserService;
import java.util.*;
public class UserW {
	UserService uservice;
	ProductService pservice;
	Scanner sc;
	List<User> ulist;
	public UserW(){
		sc=new Scanner(System.in);
		uservice=new UserService();
		pservice=new ProductService();
	}
	}
		//}


	//}
	//public void byCategory() {
		
	/*}
	
	
	public void supercoin() {
		int coin=0;
	}
	
	

}
}
*/