package com.training.project.pojo;

public class Item {
private  String itemname;
private String category;
private int buyingprice;
public String getItemname() {
	return itemname;
}
public void setItemname(String itemname) {
	this.itemname = itemname;
}
public String getCategory() {
	return category;
}
public void setCategory(String category) {
	this.category = category;
}
public int getBuyingprice() {
	return buyingprice;
}
public void setBuyingprice(int buyingprice) {
	this.buyingprice = buyingprice;
}
}
