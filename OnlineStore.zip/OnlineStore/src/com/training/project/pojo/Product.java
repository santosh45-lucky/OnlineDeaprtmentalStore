package com.training.project.pojo;
import java.util.*;
public class Product extends Item{
	private int productId;
	private String productName;
	private int sellingprice;
	Map<Integer,Product> map;
	public List<Product> getProductlist() {
		return productlist;
	}
	public void setProductlist(List<Product> productlist) {
		this.productlist = productlist;
	}
	List<Product> productlist;
	public Map<Integer, Product> getMap() {
		return map;
	}
	public void setMap(Map<Integer, Product> map) {
		this.map = map;
	}
	private int availabalequatity;
	
	public int getProductId() {
		return productId;
	}
	public int setProductId(int productId) {
		return this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getSellingprice() {
		return sellingprice;
	}
	public void setSellingprice(int sellingprice) {
		this.sellingprice = (int) (getBuyingprice()+ (getBuyingprice()*0.5));
	}
	public int getAvailabalequatity() {
		return availabalequatity;
	}
	public void setAvailabalequatity(int availabalequatity) {
		this.availabalequatity = availabalequatity;
	}
}
