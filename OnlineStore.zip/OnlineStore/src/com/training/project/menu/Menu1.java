package com.training.project.menu;
import java.sql.SQLException;
import java.util.*;

import com.jdbcdao.AdminNotFoundException;
import com.jdbcdao.UserNotFoundException;
import com.training.project.dao.UserW;
import com.training.project.service.UserService;
public class Menu1 {
Scanner sc;
UserService user;

public Menu1(){
	user=new UserService();
}
public void  showDeatils() throws SQLException {
	sc=new Scanner(System.in);
	int ch=0;
	String choice="y";
	System.out.println("****Welcome to Online Departmental Store****");
	while(choice.equals("y")){
		System.out.println("enter your choice");
		System.out.println("1.Login as Admin");
		System.out.println("2.Login as User");
		System.out.println("3.Register User");
		ch=sc.nextInt();
		switch(ch) {
		case 1:
			System.out.println("****Welcome to Admin Page****");
			try {
				user.admincheck();
		
			} catch (AdminNotFoundException e1) {
				// TODO Auto-generated catch block
				System.out.println(e1.getMessage());
			}
			break;
			
		case 2:
			System.out.println("***Welcome to Customer Page***");
			try {
				user.usercheck();
			
			} catch (UserNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
			break;
		case 3:
			user.register();
			break;
		}
		System.out.println("Do you want to continue Y/N");
		choice=sc.next();
}
}
}
