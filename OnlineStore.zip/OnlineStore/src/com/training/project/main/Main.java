package com.training.project.main;

import java.sql.SQLException;

import com.training.project.menu.Menu1;

public class Main extends Thread{
public void run() {
	try {
		Menu1 ob=new Menu1();
		ob.showDeatils();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
}

public static void main(String args[]) {
	Main th=new Main();
	th.run();
}
}
