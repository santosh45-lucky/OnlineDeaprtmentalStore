package com.training.project.service;

import java.sql.SQLException;

import com.jdbcdao.ProductIdException;
import com.jdbcdao.StoreInformationDao;
import com.training.project.dao.StoreInfo;
import com.training.project.pojo.Product;

public class ProductService {

	public StoreInformationDao productservice;
	public ProductService(){
		productservice=new StoreInformationDao();
	}
	public void itemInsert() throws SQLException {
		productservice.insert();
	}
	public void byName() throws SQLException {
		productservice.byname();
	}
	public void total() throws SQLException {
		productservice.caltotal();
	}
	public void findProfit() throws SQLException {
		productservice.calProfit();
	}
	public void byCategory() throws SQLException {
		productservice.listbycategory();
	}
	public void viewProduct() throws SQLException, ProductIdException {
		productservice.searchbyid();
	}
}
