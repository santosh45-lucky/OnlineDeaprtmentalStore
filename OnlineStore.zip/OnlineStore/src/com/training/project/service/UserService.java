package com.training.project.service;


import java.sql.SQLException;

import com.jdbcdao.AdminNotFoundException;
import com.jdbcdao.UserNotFoundException;
import com.jdbcdao.ValidationDao;
import com.training.project.dao.*;

public class UserService {

	public ValidationDao userservice;

	public UserService() {
		userservice=new ValidationDao();
	}
	public void admincheck() throws SQLException, AdminNotFoundException {	
		userservice.checkAdmin();
	}
	public void  register() throws SQLException {
		userservice.register();
	}
	public void usercheck() throws SQLException,UserNotFoundException {
		userservice.checkUser();
	}

}
