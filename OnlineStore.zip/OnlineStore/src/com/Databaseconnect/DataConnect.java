package com.Databaseconnect;
import java.sql.*;

public class DataConnect {
	private static Connection con;
	DataConnect(){
		try {
		Class.forName("com.mysql.jdbc.Driver");
		  con=DriverManager.getConnection("jdbc:mysql://localhost:3306/storeinfo","root","Santosh@123");
          //System.out.println("connection established");
	}catch(Exception e) {
		e.getMessage();
		}
	}
	 public static Connection getConnect()
	    {
	    	DataConnect d=new DataConnect();
	        return con;
	    }
	   public static void main(String args[]) {
		   getConnect();
	   }
	
}
